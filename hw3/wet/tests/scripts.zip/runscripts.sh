#!/bin/bash

cd scripts/

gnome-terminal --window -- bash -c "./tabs.sh "